-- ETL Agent — PostgreSQL schema
-- This file runs automatically on first `docker-compose up`

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ── Job tracking ──────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS jobs (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    status      TEXT NOT NULL DEFAULT 'queued',
    -- status values: queued | processing | completed | failed
    file_name   TEXT NOT NULL,
    file_path   TEXT NOT NULL,
    summary     TEXT,
    created_at  TIMESTAMPTZ DEFAULT NOW(),
    updated_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ── Per-step agent status ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS agent_steps (
    id          SERIAL PRIMARY KEY,
    job_id      UUID NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
    step        TEXT NOT NULL,
    -- step values: schema | classify | transform | load
    status      TEXT NOT NULL DEFAULT 'pending',
    -- status values: pending | running | done | failed
    payload     JSONB,
    error       TEXT,
    updated_at  TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(job_id, step)
);

-- ── Rows rejected during transform ───────────────────────────────────────
CREATE TABLE IF NOT EXISTS audit_rejections (
    id          SERIAL PRIMARY KEY,
    job_id      UUID NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
    row_index   INT,
    raw_data    JSONB,
    reason      TEXT,
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ── Training data (captured from agent runs for fine-tuning) ─────────────
CREATE TABLE IF NOT EXISTS training_examples (
    id          SERIAL PRIMARY KEY,
    agent       TEXT NOT NULL,      -- schema | classify | transform
    prompt      TEXT NOT NULL,
    completion  TEXT NOT NULL,
    is_correct  BOOLEAN,            -- null = not yet reviewed
    reviewed_by TEXT,
    reviewed_at TIMESTAMPTZ,
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ── Indexes ───────────────────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_jobs_status        ON jobs(status);
CREATE INDEX IF NOT EXISTS idx_agent_steps_job_id ON agent_steps(job_id);
CREATE INDEX IF NOT EXISTS idx_rejections_job_id  ON audit_rejections(job_id);
CREATE INDEX IF NOT EXISTS idx_training_agent     ON training_examples(agent, is_correct);
