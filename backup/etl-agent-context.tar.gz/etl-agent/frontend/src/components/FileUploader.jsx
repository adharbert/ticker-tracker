import { useState, useCallback } from "react";
import { uploadFile, getJobStatus } from "../api/etlApi";

const ACCEPTED_TYPES = [
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", // xlsx
  "application/vnd.ms-excel",                                           // xls
  "text/csv",
];

const MAX_SIZE_MB = 50;

export default function FileUploader() {
  const [file, setFile]         = useState(null);
  const [error, setError]       = useState(null);
  const [jobId, setJobId]       = useState(null);
  const [status, setStatus]     = useState(null); // null | "uploading" | "processing" | "done" | "failed"
  const [jobResult, setJobResult] = useState(null);
  const [dragOver, setDragOver] = useState(false);

  // ── Validation ─────────────────────────────────────────────────────────
  function validateFile(f) {
    if (!ACCEPTED_TYPES.includes(f.type) && !f.name.match(/\.(csv|xlsx|xls)$/i)) {
      return "Only CSV and Excel files are supported.";
    }
    if (f.size > MAX_SIZE_MB * 1024 * 1024) {
      return `File exceeds ${MAX_SIZE_MB} MB limit.`;
    }
    return null;
  }

  function handleFileSelect(f) {
    const err = validateFile(f);
    if (err) { setError(err); setFile(null); return; }
    setError(null);
    setFile(f);
    setJobId(null);
    setStatus(null);
    setJobResult(null);
  }

  // ── Drag & Drop ────────────────────────────────────────────────────────
  const onDrop = useCallback((e) => {
    e.preventDefault();
    setDragOver(false);
    const dropped = e.dataTransfer.files[0];
    if (dropped) handleFileSelect(dropped);
  }, []);

  // ── Upload & poll ──────────────────────────────────────────────────────
  async function handleUpload() {
    if (!file) return;
    setStatus("uploading");
    setError(null);

    try {
      const { jobId: id } = await uploadFile(file);
      setJobId(id);
      setStatus("processing");
      pollStatus(id);
    } catch (e) {
      setError(e.message);
      setStatus("failed");
    }
  }

  function pollStatus(id) {
    const interval = setInterval(async () => {
      try {
        const result = await getJobStatus(id);
        setJobResult(result);
        if (result.status === "completed" || result.status === "failed") {
          setStatus(result.status === "completed" ? "done" : "failed");
          clearInterval(interval);
        }
      } catch {
        clearInterval(interval);
        setStatus("failed");
      }
    }, 2000);
  }

  // ── Render ─────────────────────────────────────────────────────────────
  return (
    <div style={{ maxWidth: 640, margin: "2rem auto", fontFamily: "system-ui, sans-serif" }}>
      <h1 style={{ fontSize: "1.5rem", fontWeight: 600, marginBottom: "1.5rem", color: "#111" }}>
        ETL File Processor
      </h1>

      {/* Drop zone */}
      <div
        onDrop={onDrop}
        onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
        onDragLeave={() => setDragOver(false)}
        onClick={() => document.getElementById("fileInput").click()}
        style={{
          border: `2px dashed ${dragOver ? "#6366f1" : "#d1d5db"}`,
          borderRadius: 12,
          padding: "3rem 2rem",
          textAlign: "center",
          cursor: "pointer",
          background: dragOver ? "#eef2ff" : "#fafafa",
          transition: "all 0.2s",
          marginBottom: "1rem",
        }}
      >
        <input
          id="fileInput"
          type="file"
          accept=".csv,.xlsx,.xls"
          style={{ display: "none" }}
          onChange={(e) => e.target.files[0] && handleFileSelect(e.target.files[0])}
        />
        <div style={{ fontSize: "2.5rem", marginBottom: "0.5rem" }}>📂</div>
        <p style={{ margin: 0, color: "#6b7280", fontSize: "0.95rem" }}>
          Drop a <strong>CSV or Excel</strong> file here, or click to browse
        </p>
        <p style={{ margin: "0.25rem 0 0", color: "#9ca3af", fontSize: "0.8rem" }}>
          Max {MAX_SIZE_MB} MB · .csv, .xlsx, .xls
        </p>
      </div>

      {/* Selected file */}
      {file && (
        <div style={{
          display: "flex", alignItems: "center", gap: 12,
          padding: "0.75rem 1rem", background: "#f0fdf4",
          border: "1px solid #bbf7d0", borderRadius: 8, marginBottom: "1rem",
        }}>
          <span style={{ fontSize: "1.25rem" }}>📄</span>
          <div style={{ flex: 1 }}>
            <p style={{ margin: 0, fontWeight: 500, fontSize: "0.9rem" }}>{file.name}</p>
            <p style={{ margin: 0, color: "#6b7280", fontSize: "0.8rem" }}>
              {(file.size / 1024).toFixed(1)} KB
            </p>
          </div>
          <button
            onClick={(e) => { e.stopPropagation(); setFile(null); }}
            style={{ background: "none", border: "none", cursor: "pointer", color: "#6b7280", fontSize: "1.1rem" }}
          >✕</button>
        </div>
      )}

      {/* Error */}
      {error && (
        <div style={{
          padding: "0.75rem 1rem", background: "#fef2f2",
          border: "1px solid #fecaca", borderRadius: 8, marginBottom: "1rem",
          color: "#dc2626", fontSize: "0.9rem",
        }}>
          {error}
        </div>
      )}

      {/* Upload button */}
      <button
        onClick={handleUpload}
        disabled={!file || status === "uploading" || status === "processing"}
        style={{
          width: "100%", padding: "0.75rem",
          background: (!file || status === "uploading" || status === "processing") ? "#9ca3af" : "#6366f1",
          color: "#fff", border: "none", borderRadius: 8,
          fontSize: "1rem", fontWeight: 500, cursor: "pointer",
          transition: "background 0.2s",
        }}
      >
        {status === "uploading"   ? "Uploading..."
         : status === "processing" ? "Processing with AI agents..."
         : "Upload & Process"}
      </button>

      {/* Job status */}
      {jobId && <JobStatusPanel jobId={jobId} status={status} result={jobResult} />}
    </div>
  );
}

// ── Job Status Panel ───────────────────────────────────────────────────────
function JobStatusPanel({ jobId, status, result }) {
  const steps = [
    { key: "schema",    label: "Schema detection",     icon: "🔍" },
    { key: "classify",  label: "Column classification", icon: "🏷️" },
    { key: "transform", label: "Transform & validate",  icon: "⚙️" },
    { key: "load",      label: "Load to database",      icon: "💾" },
  ];

  const agentSteps = result?.agentSteps || {};

  return (
    <div style={{
      marginTop: "1.5rem", padding: "1.25rem",
      border: "1px solid #e5e7eb", borderRadius: 12, background: "#fff",
    }}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "1rem" }}>
        <span style={{ fontWeight: 600, fontSize: "0.95rem" }}>Job {jobId.slice(0, 8)}...</span>
        <StatusBadge status={status} />
      </div>

      {/* Agent pipeline steps */}
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {steps.map((step) => {
          const stepStatus = agentSteps[step.key] || "pending";
          return (
            <div key={step.key} style={{
              display: "flex", alignItems: "center", gap: 12,
              padding: "0.6rem 0.75rem",
              background: stepStatus === "done" ? "#f0fdf4" : stepStatus === "running" ? "#fefce8" : "#f9fafb",
              borderRadius: 8, fontSize: "0.875rem",
              border: `1px solid ${stepStatus === "done" ? "#bbf7d0" : stepStatus === "running" ? "#fde68a" : "#e5e7eb"}`,
            }}>
              <span>{step.icon}</span>
              <span style={{ flex: 1 }}>{step.label}</span>
              <StepStatus status={stepStatus} />
            </div>
          );
        })}
      </div>

      {/* Result summary */}
      {result?.summary && (
        <div style={{ marginTop: "1rem", padding: "0.75rem", background: "#f0f9ff", borderRadius: 8 }}>
          <p style={{ margin: "0 0 0.5rem", fontWeight: 500, fontSize: "0.875rem" }}>Result summary</p>
          <p style={{ margin: 0, fontSize: "0.8rem", color: "#475569", whiteSpace: "pre-wrap" }}>
            {result.summary}
          </p>
        </div>
      )}
    </div>
  );
}

function StatusBadge({ status }) {
  const map = {
    uploading:  { label: "Uploading",   bg: "#dbeafe", color: "#1d4ed8" },
    processing: { label: "Processing",  bg: "#fef9c3", color: "#854d0e" },
    done:       { label: "Complete",    bg: "#dcfce7", color: "#15803d" },
    failed:     { label: "Failed",      bg: "#fee2e2", color: "#b91c1c" },
  };
  const { label, bg, color } = map[status] || { label: "Idle", bg: "#f3f4f6", color: "#374151" };
  return (
    <span style={{ padding: "0.25rem 0.75rem", borderRadius: 99, background: bg, color, fontSize: "0.8rem", fontWeight: 500 }}>
      {label}
    </span>
  );
}

function StepStatus({ status }) {
  if (status === "done")    return <span style={{ color: "#16a34a", fontSize: "1.1rem" }}>✓</span>;
  if (status === "running") return <span style={{ color: "#d97706" }}>⟳</span>;
  if (status === "failed")  return <span style={{ color: "#dc2626" }}>✗</span>;
  return <span style={{ color: "#d1d5db" }}>○</span>;
}
