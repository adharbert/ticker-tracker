// Base URL — set via VITE_API_URL in .env
const BASE = import.meta.env.VITE_API_URL ?? "http://localhost:5000";

// ── Upload a file, returns { jobId }
export async function uploadFile(file) {
  const form = new FormData();
  form.append("file", file);

  const res = await fetch(`${BASE}/api/etl/upload`, {
    method: "POST",
    body: form,
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.message ?? `Upload failed (${res.status})`);
  }

  return res.json(); // { jobId: "uuid" }
}

// ── Poll job status, returns job object
export async function getJobStatus(jobId) {
  const res = await fetch(`${BASE}/api/etl/status/${jobId}`);

  if (!res.ok) throw new Error(`Status check failed (${res.status})`);

  return res.json();
  /*
  Expected shape:
  {
    jobId:      "uuid",
    status:     "processing" | "completed" | "failed",
    agentSteps: {
      schema:    "done" | "running" | "pending" | "failed",
      classify:  "done" | ...,
      transform: "done" | ...,
      load:      "done" | ...,
    },
    summary: "Loaded 312 rows into customers table. 4 rows rejected."
  }
  */
}
