# RAG Layer — ChromaDB + Temporal Filtering

> Claude Code: implement `python-agent/rag/` using this spec.
> The temporal filter is the single most important pattern here — never omit it.

---

## The core problem this solves

Financial news is time-sensitive in a way that trips up naive RAG.

A 2019 article about Apple earnings is semantically very similar to a 2024 Apple
earnings article — same vocabulary, same company, similar structure. A standard
vector search without a date filter will rank both equally and contaminate your
analysis with stale context.

**Rule: always filter by date BEFORE doing semantic similarity search.**

---

## ChromaDB collection design

One collection: `financial_news`

Required metadata fields on every document — these enable filtering:

```python
{
    "ticker":       "AAPL",          # primary affected ticker
    "source":       "Reuters",       # news source name
    "source_tier":  3,               # 1|2|3 credibility tier
    "publish_date": "2024-01-15",    # ISO date string — used in $gte filter
    "event_type":   "earnings",      # fed_rate|earnings|merger|regulatory|macro|other
}
```

Do NOT store full article bodies as single documents. Chunk them:
- Headline alone = 1 chunk (high weight)
- Headline + first 2 paragraphs = 1 chunk (main chunk)
- Keep chunks under 512 tokens (FinBERT and most embedders limit)

---

## File: `python-agent/rag/chroma_store.py`

```python
"""
ChromaDB interface with mandatory temporal filtering.
All queries MUST use query_recent() — never call collection.query() directly
without a date filter.
"""
import chromadb
from chromadb.utils import embedding_functions
from datetime import datetime, timedelta
import os, uuid

CHROMA_PATH  = os.getenv("CHROMA_PATH", "./chroma_db")
EMBED_MODEL  = "all-MiniLM-L6-v2"    # 80MB, local, no API cost

_client     = None
_collection = None


def _get_collection():
    global _client, _collection
    if _collection is None:
        _client = chromadb.PersistentClient(path=CHROMA_PATH)
        ef = embedding_functions.SentenceTransformerEmbeddingFunction(
                 model_name=EMBED_MODEL)
        _collection = _client.get_or_create_collection(
            name="financial_news",
            embedding_function=ef,
            metadata={"hnsw:space": "cosine"}
        )
    return _collection


def add_article(article: dict):
    """
    Store a news article in ChromaDB.
    article must have: id, text, ticker, source, source_tier, publish_date, event_type
    """
    collection = _get_collection()

    # Validate required fields before storing
    required = ["id", "text", "ticker", "source", "publish_date"]
    for field in required:
        if field not in article:
            raise ValueError(f"Missing required field for ChromaDB: {field}")

    # Deduplicate — skip if already stored
    existing = collection.get(ids=[article["id"]])
    if existing["ids"]:
        return  # already stored

    collection.add(
        documents=[article["text"]],
        ids=[article["id"]],
        metadatas=[{
            "ticker":       article["ticker"],
            "source":       article["source"],
            "source_tier":  int(article.get("source_tier", 1)),
            "publish_date": article["publish_date"],   # "YYYY-MM-DD"
            "event_type":   article.get("event_type", "other"),
        }]
    )


def query_recent(query_text: str,
                 ticker: str   = None,
                 days_back: int = 30,
                 n_results: int = 5,
                 event_type: str = None) -> dict:
    """
    TEMPORAL RAG — always filters by date before semantic search.

    Args:
        query_text:  The semantic query (usually the current headline)
        ticker:      Optional ticker filter (e.g. "AAPL")
        days_back:   How far back to search (default 30 days)
        n_results:   How many chunks to retrieve
        event_type:  Optional event type filter

    Returns:
        ChromaDB query result dict with documents, metadatas, distances
    """
    collection = _get_collection()
    cutoff     = (datetime.now() - timedelta(days=days_back)).strftime("%Y-%m-%d")

    # Build where clause — date filter is always first and always present
    where: dict = {"publish_date": {"$gte": cutoff}}

    if ticker and event_type:
        where = {"$and": [
            {"publish_date": {"$gte": cutoff}},
            {"ticker":       ticker},
            {"event_type":   event_type},
        ]}
    elif ticker:
        where = {"$and": [
            {"publish_date": {"$gte": cutoff}},
            {"ticker":       ticker},
        ]}
    elif event_type:
        where = {"$and": [
            {"publish_date": {"$gte": cutoff}},
            {"event_type":   event_type},
        ]}

    try:
        results = collection.query(
            query_texts=[query_text],
            where=where,
            n_results=n_results,
            include=["documents", "metadatas", "distances"]
        )
        return results
    except Exception:
        # ChromaDB raises if no documents match the filter — return empty
        return {"documents": [[]], "metadatas": [[]], "distances": [[]]}


def query_for_backtesting(ticker: str,
                           date_from: str,
                           date_to: str,
                           n_results: int = 50) -> dict:
    """
    Retrieve all articles for a ticker in a date range.
    Used by backtest.py to correlate signals with price moves.
    Both dates in "YYYY-MM-DD" format.
    """
    collection = _get_collection()
    where = {"$and": [
        {"ticker":       ticker},
        {"publish_date": {"$gte": date_from}},
        {"publish_date": {"$lte": date_to}},
    ]}
    try:
        return collection.query(
            query_texts=[f"{ticker} market news"],
            where=where,
            n_results=n_results,
            include=["documents", "metadatas"]
        )
    except Exception:
        return {"documents": [[]], "metadatas": [[]]}


def collection_stats() -> dict:
    """Return basic stats about the collection — useful for debugging."""
    collection = _get_collection()
    count = collection.count()
    return {"document_count": count, "collection": "financial_news"}
```

---

## File: `python-agent/rag/embedder.py`

```python
"""
Standalone embedder for cases where you need vectors outside ChromaDB.
Also used to verify the embedding model is working before first ingest.
"""
from sentence_transformers import SentenceTransformer
import os

EMBED_MODEL = os.getenv("EMBED_MODEL", "all-MiniLM-L6-v2")
_model = None

def get_model():
    global _model
    if _model is None:
        _model = SentenceTransformer(EMBED_MODEL)
    return _model

def embed(text: str) -> list[float]:
    return get_model().encode(text).tolist()

def embed_batch(texts: list[str]) -> list[list[float]]:
    return get_model().encode(texts).tolist()

def test_embedding():
    """Quick sanity check — call this on startup."""
    vec = embed("Apple earnings beat expectations")
    assert len(vec) == 384, f"Unexpected embedding dimension: {len(vec)}"
    print(f"Embedding model OK — dimension: {len(vec)}")
```

---

## Why `all-MiniLM-L6-v2` for embeddings

- 80MB download, runs on CPU, no GPU required
- 384-dimensional vectors — small enough for fast ChromaDB search
- Good enough for document retrieval; FinBERT handles the financial-domain understanding
- Alternative: `ProsusAI/finbert` for embeddings too (same model as sentiment),
  but it's 440MB and slower. Use only if retrieval quality is noticeably poor.

---

## Chunking strategy

```python
def chunk_article(headline: str, body: str, max_chars: int = 1200) -> list[str]:
    """
    Simple chunking strategy for news articles.
    Returns list of text chunks, each under max_chars.
    """
    chunks = []

    # Chunk 1: headline only (for high-weight semantic matching)
    chunks.append(headline)

    if not body:
        return chunks

    # Chunk 2: headline + first ~1200 chars of body
    combined = headline + ". " + body
    if len(combined) <= max_chars:
        chunks.append(combined)
    else:
        # Sliding window chunks with 100-char overlap
        step    = max_chars - 100
        start   = 0
        while start < len(body):
            chunk = headline + ". " + body[start:start + max_chars]
            chunks.append(chunk)
            start += step

    return chunks
```

Store each chunk with the same metadata but a unique ID:
```python
f"{article_id}_chunk_{i}"
```

---

## Claude Code instructions

1. Build `chroma_store.py` first — it's a dependency for `main.py`
2. Run `test_embedding()` from `embedder.py` as the first smoke test
3. The `query_recent()` function must never be called without a date filter
   — the date filter is inside the function, so call `query_recent()` not
   `collection.query()` directly anywhere in the codebase
4. ChromaDB persists to disk at `CHROMA_PATH` — include this path in `.gitignore`
5. On first run, sentence-transformers downloads `all-MiniLM-L6-v2` (~80MB) — expected
