# Architecture — News-to-Market Impact Agent

> Claude Code: read this before building any backend or agent code.
> Read docs/GOVERNANCE.md immediately after — governance shapes every design decision.

---

## Full data flow

```
[Scheduler: 7am daily]
        │
        ▼
.NET NewsIngestionService
  ├── Finnhub API → news articles for watchlist tickers
  ├── yfinance    → OHLCV prices for watchlist tickers (via Python HTTP call)
  └── (Phase 4) Gmail → financial alert emails
        │
        ▼ (normalize, deduplicate, publish message)
RabbitMQ queue: "news_analysis_jobs"
        │
        ▼
Python Agent Consumer (main.py)
  ├── EventClassifier  → event_type + initial confidence
  │   └── Phase 1: keyword rules
  │   └── Phase 2+: Ollama llama3.2
  │
  ├── SentimentAgent   → sentiment score + confidence
  │   └── FinBERT (ProsusAI/finbert) — local, no API cost
  │
  ├── ChromaDB RAG     → retrieve relevant historical context
  │   └── ALWAYS filter by date before semantic search
  │
  ├── ImpactReasoner   → structured impact analysis
  │   └── Ollama mistral + chain-of-thought system prompt
  │
  └── GovernanceGate   → validate_signal() — blocks bad output
        │
        ├── REJECTED → logged to rejected_signals table, not shown
        │
        └── PASSED → POST callback to .NET
                        │
                        ▼
                .NET SignalsController
                  └── INSERT into signals table
                        │
                        ▼
                React Dashboard
                  ├── SignalFeed (live poll)
                  ├── SentimentChart (Recharts)
                  └── GovernanceBadge (always visible)

[Phase 3: Backtesting]
  signals table + prices table → backtest.py
    └── BacktestGovernance.validate_backtest()
          └── BacktestPage.jsx
```

---

## Database schema

```sql
-- Watchlist
CREATE TABLE watchlist (
    ticker      TEXT PRIMARY KEY,
    name        TEXT NOT NULL,
    sector      TEXT,
    added_at    TIMESTAMPTZ DEFAULT NOW()
);

-- Raw news articles (before analysis)
CREATE TABLE news_articles (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    ticker          TEXT,                    -- primary affected ticker
    headline        TEXT NOT NULL,
    body            TEXT,
    source          TEXT NOT NULL,
    source_tier     INT DEFAULT 1,           -- 1=blog, 2=major outlet, 3=wire
    publish_date    DATE NOT NULL,
    fetched_at      TIMESTAMPTZ DEFAULT NOW(),
    event_type      TEXT,                    -- set by EventClassifier
    chroma_id       TEXT,                    -- ChromaDB document ID
    UNIQUE(headline, publish_date)           -- deduplication
);

-- Analyzed signals (passed governance gate)
CREATE TABLE signals (
    id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    article_id              UUID REFERENCES news_articles(id),
    ticker                  TEXT NOT NULL,
    event_type              TEXT NOT NULL,
    sentiment               TEXT NOT NULL,    -- bullish|bearish|neutral
    confidence              DECIMAL(4,3) NOT NULL,
    impact_summary          TEXT NOT NULL,
    time_horizon            TEXT NOT NULL,    -- intraday|days|weeks|months
    affected_sectors        TEXT[],
    source_citations        TEXT[],
    uncertainty_factors     TEXT[],
    historical_precedents   TEXT[],
    disclaimer              TEXT NOT NULL,    -- always "NOT FINANCIAL ADVICE..."
    governance_passed       BOOL NOT NULL DEFAULT TRUE,
    governance_warnings     TEXT[],
    source_credibility_tier INT NOT NULL,
    alert_suppressed        BOOL DEFAULT FALSE,
    requires_human_review   BOOL DEFAULT FALSE,
    created_at              TIMESTAMPTZ DEFAULT NOW()
);

-- Rejected signals (governance gate blocked these)
CREATE TABLE rejected_signals (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    article_id       UUID REFERENCES news_articles(id),
    rejection_reason TEXT NOT NULL,
    raw_output       JSONB,
    created_at       TIMESTAMPTZ DEFAULT NOW()
);

-- Price data
CREATE TABLE prices (
    ticker  TEXT NOT NULL,
    date    DATE NOT NULL,
    open    DECIMAL(12,4),
    high    DECIMAL(12,4),
    low     DECIMAL(12,4),
    close   DECIMAL(12,4) NOT NULL,
    volume  BIGINT,
    PRIMARY KEY (ticker, date)
);

-- Backtest results (Phase 3)
CREATE TABLE backtest_results (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    ticker           TEXT NOT NULL,
    event_type       TEXT,
    look_ahead_days  INT NOT NULL,           -- always <= 5
    sample_size      INT NOT NULL,
    accuracy         DECIMAL(5,4),           -- null if sample < 30
    baseline         DECIMAL(5,4) DEFAULT 0.50,
    vs_baseline      DECIMAL(5,4),
    disclaimer       TEXT NOT NULL,
    run_at           TIMESTAMPTZ DEFAULT NOW()
);

-- Training data (Phase 3 — labeled signals for fine-tuning)
CREATE TABLE training_examples (
    id           SERIAL PRIMARY KEY,
    signal_id    UUID REFERENCES signals(id),
    prompt       TEXT NOT NULL,
    completion   TEXT NOT NULL,
    is_correct   BOOLEAN,                    -- human-labeled
    reviewed_at  TIMESTAMPTZ,
    created_at   TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_signals_ticker     ON signals(ticker, created_at DESC);
CREATE INDEX idx_signals_event      ON signals(event_type);
CREATE INDEX idx_prices_ticker      ON prices(ticker, date DESC);
CREATE INDEX idx_articles_publish   ON news_articles(publish_date DESC);
CREATE INDEX idx_training_correct   ON training_examples(is_correct);
```

---

## Message queue format

Published by C# `NewsIngestionService`, consumed by Python `main.py`:

```json
{
  "jobType":     "analyze_article",
  "articleId":   "uuid",
  "ticker":      "AAPL",
  "headline":    "Apple Reports Record Q4 Earnings",
  "body":        "...",
  "source":      "Reuters",
  "sourceTier":  3,
  "publishDate": "2024-01-15",
  "filePath":    null
}
```

---

## Python callback to C# (after governance gate passes)

```json
{
  "articleId":            "uuid",
  "ticker":               "AAPL",
  "eventType":            "earnings",
  "sentiment":            "bullish",
  "confidence":           0.82,
  "impactSummary":        "...",
  "timeHorizon":          "days",
  "affectedSectors":      ["technology"],
  "sourceCitations":      ["Reuters: Apple Reports Record Q4..."],
  "uncertaintyFactors":   ["Macro headwinds could offset..."],
  "disclaimer":           "NOT FINANCIAL ADVICE...",
  "governancePassed":     true,
  "sourceCredibilityTier": 3,
  "governanceWarnings":   [],
  "alertSuppressed":      false,
  "requiresHumanReview":  false
}
```

---

## Key design constraints

**ChromaDB collection schema** (all fields required for temporal filtering):
```python
metadata = {
    "ticker":       "AAPL",
    "source":       "Reuters",
    "publish_date": "2024-01-15",   # ISO date string — used in $gte filter
    "event_type":   "earnings",
    "source_tier":  3,
}
```

**Finnhub free tier limits:**
- 60 API calls/minute
- News: use `/company-news` endpoint with `from` and `to` date params
- Add 1-second sleep between ticker calls to stay within rate limits
- Cache results — don't re-fetch articles already in `news_articles` table

**FinBERT input limit:**
- Max 512 tokens (~1,500 characters). Truncate body text before passing.
- Run on headline + first 2 paragraphs of body for best accuracy.

**Ollama model selection:**
- `llama3.2` for EventClassifier: fast, good at instruction following
- `mistral` for ImpactReasoner: better reasoning depth needed here
- Do not swap models without updating this doc

---

## Source credibility tier assignment

```python
# Assign in NewsIngestionService.cs or news_ingestion.py
TIER_3_SOURCES = ["reuters", "associated press", "ap", "bloomberg", "dow jones"]
TIER_2_SOURCES = ["cnbc", "wall street journal", "wsj", "financial times",
                  "marketwatch", "yahoo finance", "barron"]

def assign_tier(source: str) -> int:
    s = source.lower()
    if any(t in s for t in TIER_3_SOURCES): return 3
    if any(t in s for t in TIER_2_SOURCES): return 2
    return 1
```
