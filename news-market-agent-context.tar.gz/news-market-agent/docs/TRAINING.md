# Training — FinBERT Fine-Tuning Pipeline (Phase 3)

> Do NOT start this until Phase 2 has been running long enough to accumulate
> at least 30 labeled signals in the `training_examples` table.
> Read GOVERNANCE.md before building any backtest code.

---

## What you're actually doing

You are fine-tuning FinBERT's sentiment classification on your own labeled data
so it learns the vocabulary and patterns specific to the news sources you monitor.

**What this is:** Teaching the model that phrases common in your data ("rate hike
surprise", "guidance cut", "covenant breach") map to specific sentiment classes.

**What this is NOT:** Training a price prediction oracle.
The backtesting step measures how well your *sentiment signals* historically
correlated with price direction — it evaluates your analysis quality, not the future.

---

## Step 1: Collect labeled examples

The `training_examples` table is populated automatically when signals pass the
governance gate. Each row has `signal_id`, `prompt`, and `completion`.

Your job: manually review signals and mark `is_correct` in the DB.

```sql
-- Find unlabeled examples
SELECT te.id, s.ticker, s.event_type, s.sentiment, s.confidence,
       s.impact_summary, te.is_correct
FROM training_examples te
JOIN signals s ON te.signal_id = s.id
WHERE te.is_correct IS NULL
ORDER BY te.created_at DESC
LIMIT 20;

-- Label a batch as correct
UPDATE training_examples SET is_correct = true, reviewed_at = NOW()
WHERE id IN (1, 2, 3, 5, 7);    -- IDs you verified

-- Label as incorrect
UPDATE training_examples SET is_correct = false, reviewed_at = NOW()
WHERE id IN (4, 6);
```

**What "correct" means:** The FinBERT sentiment label (bullish/bearish/neutral)
matched what actually made sense given the news. You don't need to know if
the stock moved — just whether the sentiment classification was reasonable.

---

## Step 2: Backtest existing signals

Before fine-tuning, run the backtester to measure your baseline accuracy.
This tells you if fine-tuning is even worth attempting.

### File: `python-agent/scripts/backtest.py`

```python
"""
Correlates historical signals with actual 5-day price moves.
Governance rules enforced by BacktestGovernance.validate_backtest().
Run: python scripts/backtest.py --ticker AAPL
"""
import argparse, os, sys
import psycopg2
from datetime import datetime, timedelta
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from governance.guardrails import validate_backtest

DB_CONN        = os.getenv("DB_CONNECTION")
LOOK_AHEAD     = 5   # days — hard cap enforced by governance


def run_backtest(ticker: str) -> dict:
    conn = psycopg2.connect(DB_CONN)
    cur  = conn.cursor()

    # Fetch signals for this ticker
    cur.execute("""
        SELECT id, sentiment, confidence, created_at
        FROM signals
        WHERE ticker = %s AND governance_passed = true
        ORDER BY created_at ASC
    """, (ticker,))
    signals = cur.fetchall()

    if not signals:
        return {"ticker": ticker, "sample_size": 0, "accuracy": None,
                "look_ahead_days": LOOK_AHEAD,
                "note": "No signals found for this ticker."}

    correct   = 0
    evaluated = 0

    for sig_id, sentiment, confidence, sig_date in signals:
        # Get closing price on signal date
        price_date  = sig_date.date()
        future_date = price_date + timedelta(days=LOOK_AHEAD)

        cur.execute("""
            SELECT close FROM prices WHERE ticker = %s AND date = %s
        """, (ticker, price_date))
        row_now = cur.fetchone()

        cur.execute("""
            SELECT close FROM prices WHERE ticker = %s AND date <= %s
            ORDER BY date DESC LIMIT 1
        """, (ticker, future_date))
        row_future = cur.fetchone()

        if not row_now or not row_future:
            continue  # No price data for this date

        price_now    = float(row_now[0])
        price_future = float(row_future[0])
        actual_move  = "bullish" if price_future > price_now else "bearish"

        # Neutral signals are excluded (no directional prediction)
        if sentiment == "neutral":
            continue

        if sentiment == actual_move:
            correct += 1
        evaluated += 1

    cur.close()
    conn.close()

    accuracy = round(correct / evaluated, 4) if evaluated > 0 else None

    raw_result = {
        "ticker":           ticker,
        "sample_size":      evaluated,
        "correct":          correct,
        "accuracy":         accuracy,
        "look_ahead_days":  LOOK_AHEAD,
        "run_at":           datetime.utcnow().isoformat(),
    }

    # Apply governance rules before returning
    gov = validate_backtest(raw_result)
    return gov.result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--ticker", required=True)
    args   = parser.parse_args()

    result = run_backtest(args.ticker)
    import json
    print(json.dumps(result, indent=2, default=str))
```

**Expected output with governance applied:**
```json
{
  "ticker": "AAPL",
  "sample_size": 47,
  "correct": 27,
  "accuracy": 0.574,
  "look_ahead_days": 5,
  "baseline_accuracy": 0.50,
  "vs_baseline": 0.074,
  "disclaimer": "BACKTESTING NOTICE: ...",
  "governance_warnings": []
}
```

57.4% vs 50% baseline = +7.4% edge. That's interesting but not magical.
Anything above 70%+ warrants checking for data leakage first.

---

## Step 3: Export training data

```python
# python-agent/training/collect_labels.py
import psycopg2, json, os

DB_CONN = os.getenv("DB_CONNECTION")
AGENT   = "sentiment"   # The task we're fine-tuning on

conn = psycopg2.connect(DB_CONN)
with conn.cursor() as cur:
    cur.execute("""
        SELECT te.prompt, te.completion
        FROM training_examples te
        WHERE te.is_correct = true
        ORDER BY te.created_at DESC
    """)
    rows = cur.fetchall()

# Alpaca format for Unsloth/HuggingFace PEFT
examples = [
    {"instruction": row[0], "input": "", "output": row[1]}
    for row in rows
]

output_file = f"training_data_{AGENT}.json"
with open(output_file, "w") as f:
    json.dump(examples, f, indent=2)

print(f"Exported {len(examples)} labeled examples → {output_file}")
conn.close()
```

---

## Step 4: Fine-tune FinBERT with LoRA

```python
# python-agent/training/train_finbert.py
"""
Fine-tune ProsusAI/finbert for financial sentiment classification.
Uses PEFT LoRA — efficient, runs on a single GPU or even CPU (slow).
Requires: pip install peft transformers accelerate datasets
"""
from transformers import (AutoTokenizer, AutoModelForSequenceClassification,
                          TrainingArguments, Trainer)
from peft         import get_peft_model, LoraConfig, TaskType
from datasets     import load_dataset
import torch, json, os

BASE_MODEL  = "ProsusAI/finbert"
OUTPUT_DIR  = "./checkpoints/finbert-finetuned"
DATA_FILE   = "training_data_sentiment.json"
LABELS      = {"positive": 0, "negative": 1, "neutral": 2}
ID2LABEL    = {v: k for k, v in LABELS.items()}

# ── 1. Load tokenizer and model ───────────────────────────────────────────
tokenizer = AutoTokenizer.from_pretrained(BASE_MODEL)
model     = AutoModelForSequenceClassification.from_pretrained(
                BASE_MODEL, num_labels=3, id2label=ID2LABEL, label2id=LABELS)

# ── 2. Apply LoRA adapter ─────────────────────────────────────────────────
lora_config = LoraConfig(
    task_type      = TaskType.SEQ_CLS,
    r              = 8,           # LoRA rank — lower for smaller datasets
    lora_alpha     = 16,
    lora_dropout   = 0.1,
    target_modules = ["query", "value"],  # BERT attention layers
)
model = get_peft_model(model, lora_config)
model.print_trainable_parameters()
# Typical output: "trainable params: 296,450 || all params: 110,393,346 (0.27%)"

# ── 3. Load dataset ───────────────────────────────────────────────────────
with open(DATA_FILE) as f:
    raw = json.load(f)

# Map completions (bullish/bearish/neutral) to FinBERT labels
label_map = {"bullish": "positive", "bearish": "negative", "neutral": "neutral"}

def tokenize(examples):
    enc = tokenizer(examples["instruction"], truncation=True,
                    padding="max_length", max_length=128)
    enc["labels"] = [LABELS[label_map.get(o, "neutral")]
                     for o in examples["output"]]
    return enc

from datasets import Dataset
ds = Dataset.from_list(raw).map(tokenize, batched=True)
ds = ds.train_test_split(test_size=0.15, seed=42)

# ── 4. Train ──────────────────────────────────────────────────────────────
args = TrainingArguments(
    output_dir              = OUTPUT_DIR,
    num_train_epochs        = 5,
    per_device_train_batch_size = 8,
    learning_rate           = 2e-4,
    eval_strategy           = "epoch",
    save_strategy           = "epoch",
    load_best_model_at_end  = True,
    metric_for_best_model   = "eval_loss",
    fp16                    = torch.cuda.is_available(),
    report_to               = "none",
)

trainer = Trainer(
    model        = model,
    args         = args,
    train_dataset = ds["train"],
    eval_dataset  = ds["test"],
)
trainer.train()
trainer.save_model(OUTPUT_DIR)
print(f"Fine-tuned model saved to {OUTPUT_DIR}")
```

---

## Step 5: Evaluate — compare to baseline

```python
# python-agent/training/evaluate_model.py
"""
Compare fine-tuned FinBERT vs base FinBERT on held-out test set.
Only deploy fine-tuned model if it outperforms the base on your data.
"""
from transformers import pipeline
import json

BASE_MODEL  = "ProsusAI/finbert"
TUNED_MODEL = "./checkpoints/finbert-finetuned"

with open("test_data_sentiment.json") as f:
    tests = json.load(f)   # held-out examples NOT used in training

label_map = {"positive": "bullish", "negative": "bearish", "neutral": "neutral"}

def evaluate(model_path: str) -> float:
    pipe    = pipeline("text-classification", model=model_path,
                       return_all_scores=True)
    correct = 0
    for ex in tests:
        results   = pipe(ex["instruction"][:1500])[0]
        predicted = label_map[max(results, key=lambda x: x["score"])["label"]]
        expected  = ex["output"]   # "bullish" | "bearish" | "neutral"
        if predicted == expected:
            correct += 1
    return correct / len(tests)

print(f"Test set: {len(tests)} examples")
print(f"Base FinBERT accuracy:   {evaluate(BASE_MODEL):.1%}")
print(f"Tuned FinBERT accuracy:  {evaluate(TUNED_MODEL):.1%}")
print()
print("Deploy fine-tuned model only if it outperforms base on YOUR test set.")
print("Update FINBERT_MODEL env var to the checkpoint path if deploying.")
```

---

## Claude Code instructions

1. Run Phase 2 for at least 2 weeks before attempting Phase 3 — you need real data
2. The backtest script enforces `LOOK_AHEAD = 5` — do not make this configurable
3. Fine-tuning requires ~8GB RAM minimum (LoRA on CPU). GPU recommended but not required.
4. Keep `test_data_sentiment.json` completely separate from training data — set it
   aside before training, never train on it
5. If fine-tuned model does NOT beat baseline on held-out test set, stick with base FinBERT
6. Update `FINBERT_MODEL` env var in `.env` and restart the Python agent to use the
   fine-tuned model
