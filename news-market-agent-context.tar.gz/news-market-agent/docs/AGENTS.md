# AI Agents — Python Service Specification

> Claude Code: implement all files in `python-agent/` using this spec.
> Read ARCHITECTURE.md, GOVERNANCE.md, and RAG.md first.
> Governance gate (guardrails.py) must be built BEFORE wiring up impact_reasoner outputs.

---

## `requirements.txt`

```
# Data
pandas==2.2.2
yfinance==0.2.40
feedparser==6.0.11          # RSS ingestion (Phase 1 fallback)

# AI / ML
torch==2.3.1
transformers==4.42.3        # FinBERT
peft==0.11.1                # LoRA fine-tuning (Phase 3)
sentence-transformers==3.0.1  # ChromaDB embeddings
accelerate==0.31.0          # FinBERT inference speedup

# Vector DB
chromadb==0.5.3

# LLM (Ollama)
httpx==0.27.0               # async HTTP for Ollama + callbacks

# Queue + DB
pika==1.3.2                 # RabbitMQ
psycopg2-binary==2.9.9

# Utilities
python-dotenv==1.0.1
```

---

## File: `python-agent/main.py`

```python
import os, json, logging
import pika
from dotenv import load_dotenv
from agents.event_classifier import EventClassifier
from agents.sentiment_agent  import SentimentAgent
from agents.impact_reasoner  import ImpactReasoner
from rag.chroma_store        import add_article, query_recent
from governance.guardrails   import validate_signal
from models.ollama_client    import OllamaClient

load_dotenv()
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger(__name__)

RABBITMQ_URL = os.getenv("RABBITMQ_URL", "amqp://guest:guest@localhost:5672/")
QUEUE_NAME   = os.getenv("RABBITMQ_QUEUE", "news_analysis_jobs")
CALLBACK_URL = os.getenv("DOTNET_CALLBACK_URL")


def process_job(ch, method, properties, body):
    try:
        msg    = json.loads(body)
        log.info(f"Processing article: {msg['headline'][:60]}...")

        ollama    = OllamaClient()
        article   = msg

        # Step 1: Classify event type
        classifier  = EventClassifier(ollama)
        event_type, event_conf = classifier.classify(
            article["headline"], article.get("body", "")
        )
        article["event_type"] = event_type

        # Skip noise immediately — don't waste Ollama calls on non-events
        if event_type == "noise":
            log.info("Article classified as noise — skipping analysis.")
            ch.basic_ack(delivery_tag=method.delivery_tag)
            return

        # Step 2: Store in ChromaDB for RAG
        add_article({
            "id":           article["articleId"],
            "text":         article["headline"] + " " + article.get("body", ""),
            "ticker":       article["ticker"],
            "source":       article["source"],
            "source_tier":  article["sourceTier"],
            "publish_date": article["publishDate"],
            "event_type":   event_type,
        })

        # Step 3: FinBERT sentiment
        sentiment_agent = SentimentAgent()
        sentiment       = sentiment_agent.score(
            article["headline"] + " " + article.get("body", "")[:1500]
        )

        # Step 4: Retrieve RAG context (temporal filter applied inside)
        rag_context = query_recent(
            query_text=article["headline"],
            ticker=article["ticker"],
            days_back=30,
            n_results=3
        )
        context_texts = rag_context.get("documents", [[]])[0]

        # Step 5: Impact reasoning
        reasoner  = ImpactReasoner(ollama)
        raw_signal = reasoner.analyze(article, sentiment, context_texts)

        # Step 6: Governance gate — MANDATORY, never skip
        gov_result = validate_signal(
            raw_signal=raw_signal,
            sources=[article["source"]]
        )

        if not gov_result.passed:
            log.warning(f"Signal rejected: {gov_result.rejection_reason}")
            # POST rejection to C# for audit log
            import httpx
            httpx.post(f"{CALLBACK_URL.replace('/callback', '/rejected')}",
                json={"articleId": article["articleId"],
                      "reason": gov_result.rejection_reason}, timeout=10)
            ch.basic_ack(delivery_tag=method.delivery_tag)
            return

        # Step 7: POST passing signal to C# API
        signal = gov_result.signal
        signal["articleId"] = article["articleId"]
        signal["ticker"]    = article["ticker"]

        import httpx
        httpx.post(CALLBACK_URL, json=signal, timeout=15)
        log.info(f"Signal posted: {signal['sentiment']} {event_type} for {article['ticker']}")

        ch.basic_ack(delivery_tag=method.delivery_tag)

    except Exception as e:
        log.error(f"Job failed: {e}", exc_info=True)
        ch.basic_nack(delivery_tag=method.delivery_tag, requeue=False)


def main():
    params = pika.URLParameters(RABBITMQ_URL)
    conn   = pika.BlockingConnection(params)
    ch     = conn.channel()
    ch.queue_declare(queue=QUEUE_NAME, durable=True)
    ch.basic_qos(prefetch_count=1)
    ch.basic_consume(queue=QUEUE_NAME, on_message_callback=process_job)
    log.info(f"Listening on queue '{QUEUE_NAME}'...")
    ch.start_consuming()

if __name__ == "__main__":
    main()
```

---

## File: `python-agent/agents/event_classifier.py`

Phase 1 uses keyword rules. Phase 2 upgrades to Ollama.
The interface is identical — swap the implementation without changing `main.py`.

```python
import os
from models.ollama_client import OllamaClient

# Phase 1: keyword rules (no Ollama needed)
EVENT_KEYWORDS = {
    "fed_rate":   ["federal reserve","fed","rate hike","rate cut","fomc",
                   "interest rate","powell","basis points","bps","monetary policy"],
    "earnings":   ["earnings","eps","revenue","beats","misses","guidance",
                   "quarterly results","q1","q2","q3","q4","profit","loss"],
    "merger":     ["merger","acquisition","takeover","buyout","deal",
                   "acquired by","merges with","takeover bid"],
    "regulatory": ["sec","ftc","doj","antitrust","fine","penalty","charged",
                   "investigation","regulation","compliance","lawsuit"],
    "macro":      ["cpi","inflation","gdp","unemployment","jobs report",
                   "nonfarm payroll","pce","treasury yield","recession","fed funds"],
}

PHASE2_SYSTEM_PROMPT = """
Classify the financial news headline into exactly one category.
Return ONLY the category name. Nothing else.
Categories: fed_rate | earnings | merger | regulatory | macro | noise
"""


class EventClassifier:
    def __init__(self, ollama: OllamaClient = None):
        self.ollama      = ollama
        self.use_ollama  = os.getenv("EVENT_CLASSIFIER_USE_LLM", "false").lower() == "true"

    def classify(self, headline: str, body: str = "") -> tuple[str, float]:
        if self.use_ollama and self.ollama:
            return self._classify_llm(headline)
        return self._classify_keywords(headline, body)

    def _classify_keywords(self, headline: str, body: str) -> tuple[str, float]:
        text   = (headline + " " + body).lower()
        scores = {}
        for event_type, keywords in EVENT_KEYWORDS.items():
            matches = sum(1 for kw in keywords if kw in text)
            if matches:
                scores[event_type] = matches / len(keywords)
        if not scores:
            return "noise", 0.0
        best = max(scores, key=scores.get)
        if scores[best] < 0.05:
            return "noise", scores[best]
        return best, min(scores[best] * 10, 1.0)

    def _classify_llm(self, headline: str) -> tuple[str, float]:
        """Phase 2+ — uses Ollama for better accuracy on ambiguous headlines."""
        model    = os.getenv("EVENT_CLASSIFIER_MODEL", "llama3.2")
        response = self.ollama.generate(model, PHASE2_SYSTEM_PROMPT, headline)
        category = response.strip().lower()
        valid    = {"fed_rate","earnings","merger","regulatory","macro","noise"}
        if category not in valid:
            return "noise", 0.0
        return category, 0.85  # LLM classifications get higher base confidence
```

---

## File: `python-agent/agents/sentiment_agent.py`

```python
from transformers import pipeline
import os

FINBERT_MODEL = os.getenv("FINBERT_MODEL", "ProsusAI/finbert")
_pipeline = None

def get_pipeline():
    global _pipeline
    if _pipeline is None:
        _pipeline = pipeline(
            "text-classification",
            model=FINBERT_MODEL,
            return_all_scores=True,
            device=-1   # CPU; set device=0 for GPU
        )
    return _pipeline


class SentimentAgent:
    def score(self, text: str) -> dict:
        """
        Returns { sentiment, confidence, scores, model }
        FinBERT labels: positive, negative, neutral
        Mapped to: bullish, bearish, neutral for domain clarity
        """
        text = text[:1500]  # FinBERT 512-token limit
        pipe    = get_pipeline()
        results = pipe(text)[0]
        scores  = {r["label"]: r["score"] for r in results}

        label_map = {"positive": "bullish", "negative": "bearish", "neutral": "neutral"}
        dominant  = max(scores, key=scores.get)

        return {
            "sentiment":  label_map[dominant],
            "confidence": round(scores[dominant], 4),
            "scores":     {label_map[k]: round(v, 4) for k, v in scores.items()},
            "model":      FINBERT_MODEL,
        }
```

---

## File: `python-agent/agents/impact_reasoner.py`

```python
import os
from models.ollama_client import OllamaClient
from governance.guardrails import validate_signal

IMPACT_SYSTEM_PROMPT = """
You are a financial markets analyst assistant. Your role is EDUCATIONAL only.
Help users understand how news events have historically related to market behavior.

MANDATORY RULES — violating any rule means returning {"signal": "no_signal"}:
1. Never recommend buying or selling any security
2. Never use the words: buy, sell, invest, purchase, guaranteed, price target
3. Always cite the specific news driving your analysis
4. Always list what could make your analysis wrong
5. If confidence would be below 0.65, return {"signal": "no_signal", "reason": "..."}
6. Output ONLY valid JSON — no markdown, no explanation outside the JSON

OUTPUT SCHEMA:
{
  "event_type": "fed_rate|earnings|merger|regulatory|macro|other",
  "sentiment": "bullish|bearish|neutral",
  "confidence": 0.0-1.0,
  "affected_tickers": ["AAPL"],
  "affected_sectors": ["technology"],
  "time_horizon": "intraday|days|weeks|months",
  "impact_summary": "Educational explanation of likely market dynamics.",
  "historical_precedents": ["Similar past events and what happened."],
  "uncertainty_factors": ["What could make this analysis incorrect."],
  "source_citations": ["The specific news driving this analysis."],
  "disclaimer": "NOT FINANCIAL ADVICE. Educational analysis only."
}
"""

class ImpactReasoner:
    def __init__(self, ollama: OllamaClient):
        self.ollama = ollama
        self.model  = os.getenv("IMPACT_REASONER_MODEL", "mistral")

    def analyze(self, article: dict, sentiment: dict,
                rag_context: list[str]) -> dict:
        prompt = f"""
Event type: {article.get('event_type', 'unknown')}
Headline: {article['headline']}
FinBERT sentiment: {sentiment['sentiment']} (confidence: {sentiment['confidence']:.2f})
Affected ticker: {article.get('ticker', 'unknown')}

Recent relevant context from historical news:
{chr(10).join(f'- {c[:200]}' for c in rag_context[:3])}

Analyze the educational/historical market dynamics for this event.
"""
        response = self.ollama.generate(self.model, IMPACT_SYSTEM_PROMPT, prompt)
        return self.ollama.parse_json(response)
```

---

## File: `python-agent/models/ollama_client.py`

```python
import os, httpx, json, logging, time

log        = logging.getLogger(__name__)
OLLAMA_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")

class OllamaClient:
    def __init__(self, timeout: int = 120):
        self.timeout = timeout

    def generate(self, model: str, system: str, prompt: str, retries: int = 3) -> str:
        payload = {
            "model":   model,
            "system":  system,
            "prompt":  prompt,
            "stream":  False,
            "options": {"temperature": 0.1}
        }
        for attempt in range(retries):
            try:
                resp = httpx.post(f"{OLLAMA_URL}/api/generate",
                                  json=payload, timeout=self.timeout)
                resp.raise_for_status()
                return resp.json()["response"].strip()
            except httpx.ConnectError:
                if attempt == retries - 1:
                    raise RuntimeError(f"Ollama unreachable at {OLLAMA_URL}")
                time.sleep(2 ** attempt)

    def parse_json(self, text: str) -> dict:
        text = text.strip()
        if text.startswith("```"):
            lines = text.split("\n")
            text  = "\n".join(lines[1:-1])
        return json.loads(text)
```

---

## File: `python-agent/agents/price_fetcher.py`

```python
import yfinance as yf
import psycopg2, os
from datetime import datetime, timedelta

DB_CONN = os.getenv("DB_CONNECTION")

def fetch_and_store(tickers: list[str], days_back: int = 30):
    end   = datetime.today()
    start = end - timedelta(days=days_back)
    conn  = psycopg2.connect(DB_CONN)

    for ticker in tickers:
        df = yf.download(ticker, start=start, end=end, progress=False)
        df.reset_index(inplace=True)
        with conn:
            with conn.cursor() as cur:
                for _, row in df.iterrows():
                    cur.execute("""
                        INSERT INTO prices (ticker, date, open, high, low, close, volume)
                        VALUES (%s, %s, %s, %s, %s, %s, %s)
                        ON CONFLICT (ticker, date) DO UPDATE SET
                            close = EXCLUDED.close, volume = EXCLUDED.volume
                    """, (ticker, row["Date"].date(),
                          float(row["Open"]),  float(row["High"]),
                          float(row["Low"]),   float(row["Close"]),
                          int(row["Volume"])))
    conn.close()
```

---

## Claude Code instructions

1. Build `governance/guardrails.py` FIRST — before wiring up `impact_reasoner.py` outputs
2. Set `EVENT_CLASSIFIER_USE_LLM=false` in `.env` for Phase 1 (keyword rules only)
3. Flip to `true` in Phase 2 after Ollama is confirmed working
4. FinBERT downloads ~450MB on first run — this is expected
5. Run `ollama pull llama3.2 && ollama pull mistral` before starting `main.py`
6. The `validate_signal()` call in `main.py` is the enforcement point — never remove it
