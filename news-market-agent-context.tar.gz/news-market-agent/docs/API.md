# API Layer — C# .NET 10 Specification

> Claude Code: implement all files in `backend/` using this spec.
> Read ARCHITECTURE.md and GOVERNANCE.md first.

---

## Project setup

```bash
dotnet new webapi -n NewsMarket.Api --framework net10.0
cd NewsMarket.Api
dotnet add package Npgsql.EntityFrameworkCore.PostgreSQL
dotnet add package RabbitMQ.Client
dotnet add package Microsoft.Extensions.Http   # IHttpClientFactory for Finnhub
dotnet add package System.Text.Json
```

---

## File: `backend/Program.cs`

```csharp
using NewsMarket.Api.Services;
using NewsMarket.Api.Queue;
using NewsMarket.Api.Scheduler;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddCors(o => o.AddDefaultPolicy(p =>
    p.WithOrigins("http://localhost:5173")
     .AllowAnyHeader()
     .AllowAnyMethod()));

// HTTP client for Finnhub
builder.Services.AddHttpClient("finnhub", c => {
    c.BaseAddress = new Uri("https://finnhub.io/api/v1/");
    c.DefaultRequestHeaders.Add("X-Finnhub-Token",
        builder.Configuration["FinnhubApiKey"]);
});

// DI
builder.Services.AddScoped<INewsIngestionService, NewsIngestionService>();
builder.Services.AddScoped<ISignalService, SignalService>();
builder.Services.AddScoped<IWatchlistService, WatchlistService>();
builder.Services.AddScoped<IDigestService, DigestService>();
builder.Services.AddSingleton<IQueuePublisher, RabbitMqPublisher>();

// Daily scheduler (Phase 4 — comment out for Phase 1-2)
// builder.Services.AddHostedService<DailyIngestJob>();

builder.Services.AddNpgsqlDataSource(
    builder.Configuration.GetConnectionString("Postgres")!);

var app = builder.Build();
app.UseCors();
app.UseSwagger();
app.UseSwaggerUI();
app.MapControllers();
app.Run();
```

---

## Controllers

### `backend/Controllers/SignalsController.cs`

```csharp
[ApiController]
[Route("api/signals")]
public class SignalsController : ControllerBase
{
    private readonly ISignalService _signals;

    // GET /api/signals?ticker=AAPL&limit=20&from=2024-01-01&eventType=earnings
    [HttpGet]
    public async Task<IActionResult> GetSignals(
        [FromQuery] string? ticker,
        [FromQuery] int limit = 20,
        [FromQuery] DateTime? from = null,
        [FromQuery] string? eventType = null)
    {
        var signals = await _signals.GetSignalsAsync(ticker, limit, from, eventType);
        return Ok(signals);  // returns SignalDto[]
    }

    // GET /api/signals/:id
    [HttpGet("{id:guid}")]
    public async Task<IActionResult> GetSignal(Guid id)
    {
        var signal = await _signals.GetByIdAsync(id);
        return signal is null ? NotFound() : Ok(signal);
    }

    // POST /api/signals/callback  ← called by Python agent, not React
    [HttpPost("callback")]
    public async Task<IActionResult> Callback([FromBody] SignalCallbackDto dto)
    {
        // Enforce C# governance check before storing
        if (!dto.GovernancePassed || string.IsNullOrEmpty(dto.Disclaimer))
            return BadRequest(new { message = "Signal failed governance check." });

        await _signals.StoreSignalAsync(dto);
        return Ok();
    }
}
```

### `backend/Controllers/WatchlistController.cs`

```csharp
[ApiController]
[Route("api/watchlist")]
public class WatchlistController : ControllerBase
{
    // GET /api/watchlist
    [HttpGet]
    public async Task<IActionResult> Get() { ... }

    // POST /api/watchlist  body: { ticker: "AAPL", name: "Apple Inc" }
    [HttpPost]
    public async Task<IActionResult> Add([FromBody] WatchlistItemDto dto) { ... }

    // DELETE /api/watchlist/:ticker
    [HttpDelete("{ticker}")]
    public async Task<IActionResult> Remove(string ticker) { ... }
}
```

### `backend/Controllers/IngestController.cs`

```csharp
[ApiController]
[Route("api/ingest")]
public class IngestController : ControllerBase
{
    // POST /api/ingest/trigger  ← manual trigger for dev/testing
    // In production, replaced by DailyIngestJob scheduler
    [HttpPost("trigger")]
    public async Task<IActionResult> Trigger()
    {
        var tickers = await _watchlist.GetAllTickersAsync();
        await _ingestion.IngestAllAsync(tickers);
        return Ok(new { message = $"Ingest triggered for {tickers.Count} tickers." });
    }
}
```

### `backend/Controllers/DigestController.cs`

```csharp
[ApiController]
[Route("api/digest")]
public class DigestController : ControllerBase
{
    // GET /api/digest/latest
    [HttpGet("latest")]
    public async Task<IActionResult> Latest() { ... }

    // GET /api/digest/:date  e.g. /api/digest/2024-01-15
    [HttpGet("{date}")]
    public async Task<IActionResult> ByDate(DateOnly date) { ... }
}
```

---

## Models

### `backend/Models/Signal.cs`

```csharp
public class Signal
{
    public Guid     Id                    { get; set; } = Guid.NewGuid();
    public Guid?    ArticleId             { get; set; }
    public string   Ticker                { get; set; } = "";
    public string   EventType             { get; set; } = "";
    public string   Sentiment             { get; set; } = "";   // bullish|bearish|neutral
    public decimal  Confidence            { get; set; }
    public string   ImpactSummary         { get; set; } = "";
    public string   TimeHorizon           { get; set; } = "";
    public string[] AffectedSectors       { get; set; } = [];
    public string[] SourceCitations       { get; set; } = [];
    public string[] UncertaintyFactors    { get; set; } = [];
    public string   Disclaimer            { get; set; } = "";   // never empty
    public bool     GovernancePassed      { get; set; }
    public string[] GovernanceWarnings    { get; set; } = [];
    public int      SourceCredibilityTier { get; set; }
    public bool     AlertSuppressed       { get; set; }
    public bool     RequiresHumanReview   { get; set; }
    public DateTime CreatedAt             { get; set; } = DateTime.UtcNow;
}

// DTO returned to React — same shape as Signal + governance fields
public class SignalDto : Signal { }

// Callback from Python agent
public class SignalCallbackDto
{
    public Guid     ArticleId             { get; set; }
    public string   Ticker                { get; set; } = "";
    public string   EventType             { get; set; } = "";
    public string   Sentiment             { get; set; } = "";
    public decimal  Confidence            { get; set; }
    public string   ImpactSummary         { get; set; } = "";
    public string   TimeHorizon           { get; set; } = "";
    public string[] AffectedSectors       { get; set; } = [];
    public string[] SourceCitations       { get; set; } = [];
    public string[] UncertaintyFactors    { get; set; } = [];
    public string   Disclaimer            { get; set; } = "";
    public bool     GovernancePassed      { get; set; }
    public string[] GovernanceWarnings    { get; set; } = [];
    public int      SourceCredibilityTier { get; set; }
    public bool     AlertSuppressed       { get; set; }
    public bool     RequiresHumanReview   { get; set; }
}
```

### `backend/Models/NewsArticle.cs`

```csharp
public class NewsArticle
{
    public Guid     Id          { get; set; } = Guid.NewGuid();
    public string?  Ticker      { get; set; }
    public string   Headline    { get; set; } = "";
    public string?  Body        { get; set; }
    public string   Source      { get; set; } = "";
    public int      SourceTier  { get; set; } = 1;
    public DateOnly PublishDate { get; set; }
    public DateTime FetchedAt   { get; set; } = DateTime.UtcNow;
    public string?  EventType   { get; set; }
    public string?  ChromaId    { get; set; }
}
```

---

## Services

### `backend/Services/NewsIngestionService.cs`

```csharp
public class NewsIngestionService : INewsIngestionService
{
    private readonly IHttpClientFactory _http;
    private readonly IQueuePublisher    _queue;
    // Finnhub endpoint: GET /company-news?symbol=AAPL&from=2024-01-01&to=2024-01-15

    public async Task IngestAllAsync(List<string> tickers)
    {
        var client = _http.CreateClient("finnhub");
        var from   = DateOnly.FromDateTime(DateTime.UtcNow.AddDays(-1));
        var to     = DateOnly.FromDateTime(DateTime.UtcNow);

        foreach (var ticker in tickers)
        {
            var url      = $"company-news?symbol={ticker}&from={from:yyyy-MM-dd}&to={to:yyyy-MM-dd}";
            var response = await client.GetFromJsonAsync<List<FinnhubArticle>>(url);

            foreach (var article in response ?? [])
            {
                // Dedup check — skip if headline+date already in DB
                if (await ArticleExistsAsync(article.Headline, from)) continue;

                var normalized = NormalizeArticle(article, ticker);
                var id         = await StoreArticleAsync(normalized);

                await _queue.PublishAsync(new QueueMessage
                {
                    JobType     = "analyze_article",
                    ArticleId   = id,
                    Ticker      = ticker,
                    Headline    = article.Headline,
                    Body        = article.Summary,
                    Source      = article.Source,
                    SourceTier  = AssignTier(article.Source),
                    PublishDate = from.ToString("yyyy-MM-dd"),
                });
            }

            await Task.Delay(1000); // Respect Finnhub rate limit (60 req/min)
        }
    }

    private int AssignTier(string source)
    {
        var s = source.ToLower();
        if (new[] {"reuters","bloomberg","associated press","dow jones"}.Any(t => s.Contains(t))) return 3;
        if (new[] {"cnbc","wall street journal","wsj","financial times","marketwatch"}.Any(t => s.Contains(t))) return 2;
        return 1;
    }
}
```

---

## `backend/appsettings.Development.json`

```json
{
  "ConnectionStrings": {
    "Postgres": "Host=localhost;Database=news_market;Username=postgres;Password=postgres"
  },
  "RabbitMq": {
    "Host":  "localhost",
    "Queue": "news_analysis_jobs"
  },
  "FinnhubApiKey": "YOUR_FREE_KEY_HERE",
  "PythonAgent": {
    "CallbackUrl": "http://localhost:5000/api/signals/callback"
  },
  "Watchlist": {
    "DefaultTickers": ["AAPL", "MSFT", "TSLA", "SPY", "QQQ"]
  },
  "Scheduler": {
    "DailyIngestTime": "07:00"
  }
}
```

---

## Claude Code instructions for this layer

1. Implement real Npgsql DB queries in all service methods (replace `TODO` stubs)
2. The `SignalCallbackDto` governance check in `SignalsController` is mandatory —
   never remove or weaken it
3. `IngestController.trigger` is dev-only — add `[ApiExplorerSettings(IgnoreApi = true)]`
   before deploying, or gate behind an env check
4. Finnhub free tier: 60 req/min, so the 1-second sleep between tickers is required
5. Add duplicate detection in `NewsIngestionService` — check `UNIQUE(headline, publish_date)`
   in DB before queuing
