-- News-to-Market Agent — PostgreSQL schema
-- Runs automatically on first docker-compose up

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ── Watchlist ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS watchlist (
    ticker      TEXT PRIMARY KEY,
    name        TEXT NOT NULL,
    sector      TEXT,
    added_at    TIMESTAMPTZ DEFAULT NOW()
);

-- Default watchlist
INSERT INTO watchlist (ticker, name, sector) VALUES
    ('AAPL',  'Apple Inc.',              'Technology'),
    ('MSFT',  'Microsoft Corporation',   'Technology'),
    ('TSLA',  'Tesla, Inc.',             'Consumer Discretionary'),
    ('SPY',   'SPDR S&P 500 ETF',        'ETF'),
    ('QQQ',   'Invesco QQQ Trust',       'ETF')
ON CONFLICT DO NOTHING;

-- ── Raw news articles ──────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS news_articles (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    ticker          TEXT,
    headline        TEXT NOT NULL,
    body            TEXT,
    source          TEXT NOT NULL,
    source_tier     INT  NOT NULL DEFAULT 1,  -- 1=blog 2=major 3=wire
    publish_date    DATE NOT NULL,
    fetched_at      TIMESTAMPTZ DEFAULT NOW(),
    event_type      TEXT,
    chroma_id       TEXT,
    UNIQUE(headline, publish_date)            -- deduplication
);

-- ── Signals (passed governance gate) ──────────────────────────────────────
CREATE TABLE IF NOT EXISTS signals (
    id                       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    article_id               UUID REFERENCES news_articles(id),
    ticker                   TEXT NOT NULL,
    event_type               TEXT NOT NULL,
    sentiment                TEXT NOT NULL,   -- bullish|bearish|neutral
    confidence               DECIMAL(4,3) NOT NULL,
    impact_summary           TEXT NOT NULL,
    time_horizon             TEXT NOT NULL,   -- intraday|days|weeks|months
    affected_sectors         TEXT[],
    source_citations         TEXT[],
    uncertainty_factors      TEXT[],
    historical_precedents    TEXT[],
    disclaimer               TEXT NOT NULL,   -- NEVER empty
    governance_passed        BOOL NOT NULL DEFAULT TRUE,
    governance_warnings      TEXT[],
    source_credibility_tier  INT  NOT NULL,
    alert_suppressed         BOOL DEFAULT FALSE,
    requires_human_review    BOOL DEFAULT FALSE,
    created_at               TIMESTAMPTZ DEFAULT NOW()
);

-- ── Rejected signals (governance blocked) ─────────────────────────────────
CREATE TABLE IF NOT EXISTS rejected_signals (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    article_id       UUID REFERENCES news_articles(id),
    rejection_reason TEXT NOT NULL,
    raw_output       JSONB,
    created_at       TIMESTAMPTZ DEFAULT NOW()
);

-- ── Price data ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS prices (
    ticker  TEXT NOT NULL,
    date    DATE NOT NULL,
    open    DECIMAL(12,4),
    high    DECIMAL(12,4),
    low     DECIMAL(12,4),
    close   DECIMAL(12,4) NOT NULL,
    volume  BIGINT,
    PRIMARY KEY (ticker, date)
);

-- ── Backtest results (Phase 3) ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS backtest_results (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    ticker           TEXT NOT NULL,
    event_type       TEXT,
    look_ahead_days  INT  NOT NULL CHECK (look_ahead_days <= 5),  -- governance: max 5
    sample_size      INT  NOT NULL,
    accuracy         DECIMAL(5,4),   -- NULL if sample_size < 30
    baseline         DECIMAL(5,4)    NOT NULL DEFAULT 0.50,
    vs_baseline      DECIMAL(5,4),
    disclaimer       TEXT NOT NULL,
    run_at           TIMESTAMPTZ DEFAULT NOW()
);

-- ── Training examples (Phase 3) ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS training_examples (
    id           SERIAL PRIMARY KEY,
    signal_id    UUID REFERENCES signals(id),
    prompt       TEXT NOT NULL,
    completion   TEXT NOT NULL,
    is_correct   BOOLEAN,          -- NULL = not yet reviewed
    reviewed_at  TIMESTAMPTZ,
    created_at   TIMESTAMPTZ DEFAULT NOW()
);

-- ── Daily digests (Phase 4) ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS digests (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    digest_date  DATE NOT NULL UNIQUE,
    html_content TEXT,
    text_content TEXT,
    signal_count INT  DEFAULT 0,
    created_at   TIMESTAMPTZ DEFAULT NOW()
);

-- ── Indexes ───────────────────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_signals_ticker    ON signals(ticker, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_signals_event     ON signals(event_type);
CREATE INDEX IF NOT EXISTS idx_signals_sentiment ON signals(sentiment);
CREATE INDEX IF NOT EXISTS idx_prices_ticker     ON prices(ticker, date DESC);
CREATE INDEX IF NOT EXISTS idx_articles_publish  ON news_articles(publish_date DESC);
CREATE INDEX IF NOT EXISTS idx_articles_ticker   ON news_articles(ticker);
CREATE INDEX IF NOT EXISTS idx_training_correct  ON training_examples(is_correct);
CREATE INDEX IF NOT EXISTS idx_rejected_date     ON rejected_signals(created_at DESC);
